"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformSecuritySchemes = exports.isPostmanSecuritySchemeEqual = exports.transformSecurityScheme = exports.isStandardSecurityScheme = void 0;
const types_1 = require("@stoplight/types");
const utils_1 = require("../../utils");
const id_1 = require("../id");
function isStandardSecurityScheme(pss) {
    return pss.type === 'securityScheme';
}
exports.isStandardSecurityScheme = isStandardSecurityScheme;
function transformSecurityScheme(auth, nextKey) {
    const parameters = auth.parameters();
    switch (auth.type) {
        case 'oauth1':
            if (parameters.get('addParamsToHeader')) {
                return {
                    type: 'headerParams',
                    headerParams: [
                        {
                            id: (0, id_1.generateId)(),
                            name: 'Authorization',
                            style: types_1.HttpParamStyles.Simple,
                            description: 'OAuth1 Authorization Header',
                            required: true,
                            examples: [
                                {
                                    id: (0, id_1.generateId)(),
                                    key: 'default',
                                    value: 'OAuth ' +
                                        [
                                            ['realm', parameters.get('realm') || 'a_realm'],
                                            ['oauth_consumer_key', 'a_consumer_key'],
                                            ['oauth_token', 'a_token'],
                                            ['oauth_signature_method', parameters.get('signatureMethod') || 'HMAC-SHA1'],
                                            ['oauth_timestamp', parameters.get('timestamp') || '0'],
                                            ['oauth_nonce', 'a'],
                                            ['oauth_version', parameters.get('version')],
                                            ['oauth_signature', 'a_signature'],
                                        ]
                                            .map(([k, v]) => `${k}="${v}"`)
                                            .join(','),
                                },
                            ],
                        },
                    ],
                };
            }
            else {
                const required = !parameters.get('addEmptyParamsToSign');
                return {
                    type: 'queryParams',
                    queryParams: [
                        { id: (0, id_1.generateId)(), name: 'oauth_consumer_key', style: types_1.HttpParamStyles.Form, required },
                        { id: (0, id_1.generateId)(), name: 'oauth_token', style: types_1.HttpParamStyles.Form, required },
                        {
                            id: (0, id_1.generateId)(),
                            name: 'oauth_signature_method',
                            style: types_1.HttpParamStyles.Form,
                            required,
                            examples: parameters.has('signatureMethod')
                                ? [{ id: (0, id_1.generateId)(), key: 'default', value: parameters.get('signatureMethod') }]
                                : [],
                        },
                        {
                            id: (0, id_1.generateId)(),
                            name: 'oauth_timestamp',
                            style: types_1.HttpParamStyles.Form,
                            required,
                            schema: { type: 'string' },
                            examples: parameters.has('timestamp')
                                ? [{ id: (0, id_1.generateId)(), key: 'default', value: parameters.get('timestamp') }]
                                : [],
                        },
                        { id: (0, id_1.generateId)(), name: 'oauth_nonce', style: types_1.HttpParamStyles.Form, required },
                        {
                            id: (0, id_1.generateId)(),
                            name: 'oauth_version',
                            style: types_1.HttpParamStyles.Form,
                            required,
                            examples: parameters.has('version')
                                ? [{ id: (0, id_1.generateId)(), key: 'default', value: parameters.get('version') }]
                                : [],
                        },
                        { id: (0, id_1.generateId)(), name: 'oauth_signature', style: types_1.HttpParamStyles.Form, required },
                    ],
                };
            }
        case 'oauth2':
            if (parameters.get('addTokenTo') === 'queryParams') {
                return {
                    type: 'queryParams',
                    queryParams: [
                        {
                            id: (0, id_1.generateId)(),
                            name: 'access_token',
                            description: 'OAuth2 Access Token',
                            style: types_1.HttpParamStyles.Form,
                            required: true,
                        },
                    ],
                };
            }
            else {
                return {
                    type: 'securityScheme',
                    securityScheme: {
                        id: (0, id_1.generateId)(),
                        key: nextKey('oauth2'),
                        type: 'http',
                        scheme: 'bearer',
                        description: 'OAuth2 Access Token',
                        extensions: {},
                    },
                };
            }
        case 'apikey':
            return {
                type: 'securityScheme',
                securityScheme: {
                    id: (0, id_1.generateId)(),
                    key: nextKey('apiKey'),
                    type: 'apiKey',
                    name: parameters.get('key'),
                    in: parameters.get('in') || 'header',
                    extensions: {},
                },
            };
        case 'basic':
        case 'digest':
        case 'bearer':
            return {
                type: 'securityScheme',
                securityScheme: {
                    id: (0, id_1.generateId)(),
                    key: nextKey('http'),
                    type: 'http',
                    scheme: auth.type,
                    extensions: {},
                },
            };
        case 'hawk':
            return {
                type: 'headerParams',
                headerParams: [
                    {
                        id: (0, id_1.generateId)(),
                        name: 'Authorization',
                        description: 'Hawk Authorization Header',
                        required: true,
                        style: types_1.HttpParamStyles.Simple,
                        schema: {
                            type: 'string',
                            pattern: '^Hawk .+$',
                        },
                    },
                ],
            };
        case 'awsv4':
            return {
                type: 'headerParams',
                headerParams: [
                    {
                        id: (0, id_1.generateId)(),
                        name: 'X-Amz-Security-Token',
                        style: types_1.HttpParamStyles.Simple,
                        required: true,
                    },
                    {
                        id: (0, id_1.generateId)(),
                        name: 'X-Amz-Date',
                        style: types_1.HttpParamStyles.Simple,
                        required: true,
                    },
                    {
                        id: (0, id_1.generateId)(),
                        name: 'Authorization',
                        style: types_1.HttpParamStyles.Simple,
                        required: true,
                        description: 'AWS v4 Authorization Header',
                    },
                ],
            };
        case 'edgegrid':
            return {
                type: 'headerParams',
                headerParams: [
                    {
                        id: (0, id_1.generateId)(),
                        name: 'Authorization',
                        style: types_1.HttpParamStyles.Simple,
                        required: true,
                        description: 'Akamai EdgeGrid Authorization Header',
                    },
                ],
            };
        case 'ntlm':
            return {
                type: 'headerParams',
                headerParams: [
                    {
                        id: (0, id_1.generateId)(),
                        name: 'Authorization',
                        description: 'NTLM Authorization Header',
                        required: true,
                        style: types_1.HttpParamStyles.Simple,
                        schema: {
                            type: 'string',
                            pattern: '^NTLM .+$',
                        },
                    },
                ],
            };
        case 'noauth':
            return;
        default:
            return;
    }
}
exports.transformSecurityScheme = transformSecurityScheme;
function isPostmanSecuritySchemeEqual(pss1, pss2) {
    if (pss1.type !== pss2.type)
        return false;
    if (isStandardSecurityScheme(pss1) && isStandardSecurityScheme(pss2)) {
        return (0, utils_1.isEqual)({ ...pss1.securityScheme, key: '' }, { ...pss2.securityScheme, key: '' });
    }
    return (0, utils_1.isEqual)(pss1, pss2);
}
exports.isPostmanSecuritySchemeEqual = isPostmanSecuritySchemeEqual;
function transformSecuritySchemes(collection) {
    const postmanSecuritySchemes = [];
    let securitySchemeIdx = 0;
    function addSecurityScheme(pss) {
        if (!postmanSecuritySchemes.find(p => isPostmanSecuritySchemeEqual(p, pss))) {
            postmanSecuritySchemes.push(pss);
        }
    }
    collection.forEachItem(item => {
        const auth = item.getAuth();
        if (auth) {
            const transformed = transformSecurityScheme(auth, type => `${type}-${securitySchemeIdx++}`);
            if (transformed)
                addSecurityScheme(transformed);
        }
    });
    collection.forEachItemGroup(itemGroup => {
        if (itemGroup.auth) {
            const transformed = transformSecurityScheme(itemGroup.auth, type => `${type}-${securitySchemeIdx++}`);
            if (transformed)
                addSecurityScheme(transformed);
        }
    });
    return postmanSecuritySchemes;
}
exports.transformSecuritySchemes = transformSecuritySchemes;
//# sourceMappingURL=securityScheme.js.map