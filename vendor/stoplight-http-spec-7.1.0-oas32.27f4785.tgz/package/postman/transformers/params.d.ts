import { IHttpHeaderParam, IHttpOperationRequestBody, IHttpPathParam, IHttpQueryParam, IMediaTypeContent } from '@stoplight/types';
import type { Header, QueryParam, RequestBody } from 'postman-collection';
export declare function transformQueryParam(queryParam: QueryParam): IHttpQueryParam;
export declare function transformHeader(header: Header): IHttpHeaderParam;
export declare function transformPathParams(segments: string[]): IHttpPathParam[];
export declare function transformBody(body: RequestBody, mediaType?: string): IHttpOperationRequestBody | undefined;
export declare function transformRawBody(raw: string, mediaType?: string): IMediaTypeContent;
