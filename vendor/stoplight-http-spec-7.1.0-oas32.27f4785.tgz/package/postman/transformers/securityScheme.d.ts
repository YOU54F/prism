import { HttpSecurityScheme, IHttpHeaderParam, IHttpQueryParam } from '@stoplight/types';
import type { Collection, RequestAuth } from 'postman-collection';
export declare type PostmanSecurityScheme = StandardSecurityScheme | QuerySecurityScheme | HeaderSecurityScheme;
export declare type StandardSecurityScheme = {
    type: 'securityScheme';
    securityScheme: HttpSecurityScheme;
};
export declare type QuerySecurityScheme = {
    type: 'queryParams';
    queryParams: IHttpQueryParam[];
};
export declare type HeaderSecurityScheme = {
    type: 'headerParams';
    headerParams: IHttpHeaderParam[];
};
export declare function isStandardSecurityScheme(pss: PostmanSecurityScheme): pss is StandardSecurityScheme;
export declare function transformSecurityScheme(auth: RequestAuth, nextKey: (type: HttpSecurityScheme['type']) => string): PostmanSecurityScheme | undefined;
export declare function isPostmanSecuritySchemeEqual(pss1: PostmanSecurityScheme, pss2: PostmanSecurityScheme): boolean;
export declare function transformSecuritySchemes(collection: Collection): PostmanSecurityScheme[];
