import type { IHttpParam } from '@stoplight/types';
import { Collection, CollectionDefinition, DescriptionDefinition, Version } from 'postman-collection';
export declare function transformStringValueToSchema(value: string): Pick<IHttpParam, 'schema' | 'examples'>;
export declare function transformDescriptionDefinition(description: string | DescriptionDefinition): string;
export declare function resolveCollection(collectionDefinition: CollectionDefinition): Collection;
export declare function resolveVersion(version: Version): string;
